# 華耀東夷堂 (kytid_official)

競輪をメインとした匿名掲示板サイト。
スマートフォン優先のSPA構成。Supabaseをバックエンドとして使用。

---

## ファイル構成

```
index.html   シェルのみ。HTMLの骨格・利用規約テキスト。JSは持たない
style.css    全スタイル。デザイントークン（色・余白・タイポ）はここに集約
bg.js        背景演出（星フィールド + 夜景ビル群 + 車アニメ）
flow.js      起動フロー（スプラッシュ → 利用規約 → 掲示板）
board.js     掲示板ロジック（Supabase CRUD・リアルタイム）
assets/
  logo.png       サイトロゴ（ヘッダー・サイドバー）
  wheel-eye.png  スプラッシュ画面のアイコン
```

---

## デザイントークン

| 用途           | 値        |
|----------------|-----------|
| ベース背景      | `#0f1420` |
| 最暗部（画面外）| `#060a10` |
| アクセント（琥珀）| `#c8a060` |
| アクセント（暗）| `#8a6a3a` |
| テキスト（主）  | `#f0ece4` |
| テキスト（副）  | `#ddd6c8` |
| テキスト（弱）  | `#9aa0b0` |
| ミュート        | `#5a6278` |
| フェイント      | `#3a4058` |
| サイドバー背景  | `#0b0f1a` |
| ヘッダー背景    | `#0d1220` |
| アクティブ背景  | `#1a2236` |
| ホバー背景      | `#141b2a` |

フォント:
- 本文: `Noto Sans JP`（Google Fonts）
- ID・時刻・モノスペース: `IBM Plex Mono`（Google Fonts）

---

## 画面遷移

```
Scene 1: スプラッシュ（3.5秒）
  └→ Scene 2: 利用規約（最下部スクロールで同意ボタン活性化）
       └→ Scene 3: 掲示板本体（board.js の _boardInit() で初期化）
```

起動フローの制御は `flow.js` のみ。
掲示板の初期化タイミングは `flow.js` → `window._boardInit()` → `board.js`。

---

## 掲示板の状態遷移

```
板一覧（showBoards）
  └→ スレッド一覧（showThreads(board)）
       └→ 投稿一覧（showPosts(thread)）
```

状態変数（board.js グローバル）:
- `view`: `'boards'` | `'threads'` | `'posts'`
- `currentBoard`: 選択中の板オブジェクト
- `currentThread`: 選択中のスレッドオブジェクト
- `posts`: 現在表示中の投稿配列
- `boards`: 板一覧キャッシュ

---

## Supabase

| 項目 | 値 |
|------|-----|
| Project URL | `https://pqqrfzofzxiuzvxdrcai.supabase.co` |
| Publishable Key | `sb_publishable_t1AfJtM9h_gYkxg9QL3GXg_-CVV0jaT` |

### テーブル構成（推定）

```
boards
  id, name, emoji, created_at

threads
  id, board_id, title, post_count, is_active, created_at

posts
  id, thread_id, post_number, anon_id, body, created_at
```

### RPC

| 関数 | 用途 |
|------|------|
| `insert_post(p_thread_id, p_body, p_anon_id)` | 投稿送信 |
| `create_thread(p_board_id, p_title, p_body, p_anon_id)` | スレッド作成 |

### リアルタイム

`posts` テーブルへの INSERT をリアルタイム購読。
スレッド遷移時に `unsubscribe()` → 新スレッドで再購読。

---

## 背景演出（bg.js）

- **星フィールド**: `#starfield` canvas（bg-layer内）。白・琥珀のピクセル点が微明滅。
- **夜景ビル群**: `#city-canvas` canvas（bg-layer内）。ビル・電柱・窓の明かり・車の通過アニメ。
- `#bg-layer` は `position:fixed; z-index:0` で `#stage` の背後に配置。
- `#stage` は `z-index:1; background:#0f1420` で完全不透明 → 背景演出はコンテンツエリアに干渉しない。

---

## 注意事項

- スレッド作成ボタンは一般画面から除去済み。管理ページからのみ作成可能。
- 匿名ID (`myAnonId`) は `localStorage` に保存。サーバー側での24hリセットは別途実装が必要。
- `board.js` のグローバル変数（`showAnchorPopup`, `hideAnchorPopup`, `scrollToPost`）は
  投稿HTML内の `onmouseenter`/`onclick` から参照するためグローバルスコープに置いている。
